#pragma once

#include <stdio.h>
#include <string.h>
#include <stdlib.h>


//#define MAX 200
#define MAX_NAME 20
#define MAX_SEX 5
#define MAX_TEL 13
#define MAX_ADDR 30

#define DEFAULT_SZ 3

enum Option
{
	EXIT,//0
	ADD,//1
	DEL,//2
	SEARCH,//3
	MODIFY,//4
	SHOW,//5
	SORT//6
};

typedef struct PeoInfo
{
	char name[MAX_NAME];
	int age;
	char sex[MAX_SEX];
	char tel[MAX_TEL];
	char addr[MAX_ADDR];
}PeoInfo;

//ͨѶ¼����
typedef struct Contact
{
	struct PeoInfo *data;//�����ϵ�˵Ŀռ�
	int size;//��¼��ǰ������ϵ�˸���
	int capacity;//��ǰͨѶ¼��С
}Contact;

//��������
void InitContact(Contact* ps);

void AddContact(Contact* ps);

void ShowContact(const Contact* ps);

void DelContact(Contact* ps);

void SearchContact(const Contact* ps);

void ModifyContact(Contact* ps);

void SortContact(Contact* ps);

void DestroyContact(Contact* ps);

